import SocialBar from '../SocialBar';

export default function SocialBarExample() {
  return <SocialBar />;
}
