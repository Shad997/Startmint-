import ProductGallery from '../ProductGallery';

export default function ProductGalleryExample() {
  return <ProductGallery />;
}
