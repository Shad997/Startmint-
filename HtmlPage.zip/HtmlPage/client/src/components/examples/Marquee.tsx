import Marquee from '../Marquee';

export default function MarqueeExample() {
  return <Marquee />;
}
