import SpotRateCard from '../SpotRateCard';

export default function SpotRateCardExample() {
  const mockRate = {
    name: 'GOLDoz',
    bid: 4072.95,
    ask: 4074.85,
    low: 3997.81,
    high: 4078.36
  };
  
  return <SpotRateCard rate={mockRate} />;
}
