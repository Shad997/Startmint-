import CommodityTable from '../CommodityTable';

export default function CommodityTableExample() {
  const mockPrices = [
    { commodity: 'GOLD', purity: '999', unit: '1 GM', bid: 480.63, ask: 482.27 },
    { commodity: 'GOLD', purity: '9999', unit: '1 KG', bid: 481064, ask: 482705 },
  ];
  
  return <CommodityTable prices={mockPrices} />;
}
