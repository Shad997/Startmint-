import { CommodityPrice } from '@/hooks/useLivePrices';

interface CommodityTableProps {
  prices: CommodityPrice[];
}

export default function CommodityTable({ prices }: CommodityTableProps) {
  return (
    <div className="bg-card/50 rounded-lg border-2 border-primary/30 p-6" data-testid="table-commodity">
      <div className="grid grid-cols-4 gap-4 mb-4 pb-3 border-b border-primary/20">
        <div className="font-bold text-primary text-lg" data-testid="text-header-commodity">COMMODITY</div>
        <div className="font-bold text-primary text-lg" data-testid="text-header-unit">UNIT</div>
        <div className="font-bold text-primary text-lg" data-testid="text-header-bid">BID (AED)</div>
        <div className="font-bold text-primary text-lg" data-testid="text-header-ask">ASK (AED)</div>
      </div>
      
      {prices.map((price, index) => (
        <div 
          key={index}
          className="grid grid-cols-4 gap-4 bg-white dark:bg-white text-black p-4 rounded-md mb-3 font-semibold hover-elevate"
          data-testid={`row-price-${index}`}
        >
          <div className="flex items-center gap-2" data-testid={`text-commodity-${index}`}>
            <span className="font-bold">{price.commodity}</span>
            <span className="text-sm text-black/70">{price.purity}</span>
          </div>
          <div data-testid={`text-unit-${index}`}>{price.unit}</div>
          <div className="font-mono" data-testid={`text-bid-${index}`}>
            {price.bid.toLocaleString('en-US', { minimumFractionDigits: price.unit === '1 GM' ? 2 : 0 })}
          </div>
          <div className="font-mono" data-testid={`text-ask-${index}`}>
            {price.ask.toLocaleString('en-US', { minimumFractionDigits: price.unit === '1 GM' ? 2 : 0 })}
          </div>
        </div>
      ))}
    </div>
  );
}
