export default function Marquee() {
  const text = "STARMINT TRADING COMPANY L.L.C • FINE GOLD JEWELRY • DUBAI • LUXURY CRAFTSMANSHIP • ";
  
  return (
    <div className="bg-gradient-to-r from-primary/20 via-primary/30 to-primary/20 border-y border-primary/30 py-4 overflow-hidden" data-testid="section-marquee">
      <div className="flex whitespace-nowrap animate-marquee">
        <span className="text-2xl font-bold text-primary tracking-widest inline-block px-8" style={{ fontFamily: 'Cinzel, serif' }}>
          {text.repeat(3)}
        </span>
      </div>
      
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-33.333%); }
        }
        .animate-marquee {
          animation: marquee 40s linear infinite;
        }
      `}</style>
    </div>
  );
}
