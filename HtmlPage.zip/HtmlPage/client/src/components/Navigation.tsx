import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Phone } from "lucide-react";
import starmintLogo from "@assets/1744184644734-removebg-preview_1762756809920.png";

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-background/95 backdrop-blur-md border-b border-primary/20 shadow-lg' : 'bg-transparent'
        }`}
        data-testid="nav-header"
      >
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img 
                src={starmintLogo} 
                alt="Starmint Logo" 
                className="w-12 h-12 object-contain cursor-pointer"
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                data-testid="img-nav-logo"
              />
              <div className="hidden md:block">
                <h2 className="font-serif text-lg font-bold text-primary" data-testid="text-nav-company">Starmint</h2>
                <p className="text-xs text-muted-foreground" data-testid="text-nav-subtitle">Trading Company</p>
              </div>
            </div>
            
            <div className="hidden md:flex items-center gap-8">
              <button 
                onClick={() => scrollToSection('gallery')}
                className="text-foreground hover:text-primary transition-colors font-medium"
                data-testid="link-nav-collection"
              >
                Collection
              </button>
              <button 
                onClick={() => scrollToSection('about')}
                className="text-foreground hover:text-primary transition-colors font-medium"
                data-testid="link-nav-about"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="text-foreground hover:text-primary transition-colors font-medium"
                data-testid="link-nav-contact"
              >
                Contact
              </button>
              <Button 
                size="sm"
                className="bg-primary text-primary-foreground"
                onClick={() => window.open('tel:+971585054666', '_self')}
                data-testid="button-nav-call"
              >
                <Phone className="w-4 h-4 mr-2" />
                Call Now
              </Button>
            </div>
            
            <button 
              className="md:hidden text-foreground"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              data-testid="button-mobile-menu-toggle"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </nav>
      
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-background/98 backdrop-blur-md md:hidden" data-testid="menu-mobile">
          <div className="flex flex-col items-center justify-center h-full gap-8">
            <button 
              onClick={() => scrollToSection('gallery')}
              className="text-2xl font-serif text-foreground hover:text-primary transition-colors"
              data-testid="link-mobile-collection"
            >
              Collection
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className="text-2xl font-serif text-foreground hover:text-primary transition-colors"
              data-testid="link-mobile-about"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className="text-2xl font-serif text-foreground hover:text-primary transition-colors"
              data-testid="link-mobile-contact"
            >
              Contact
            </button>
            <Button 
              size="lg"
              className="bg-primary text-primary-foreground"
              onClick={() => window.open('tel:+971585054666', '_self')}
              data-testid="button-mobile-call"
            >
              <Phone className="w-5 h-5 mr-2" />
              Call Now
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
