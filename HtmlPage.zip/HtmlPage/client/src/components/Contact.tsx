import { Card } from "@/components/ui/card";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

const contactInfo = [
  {
    icon: MapPin,
    title: "Location",
    details: ["Shop No-04 Al Buteen Building 2", "Gate No.1, Gold Souq", "Deira, Dubai, UAE"]
  },
  {
    icon: Phone,
    title: "Phone Numbers",
    details: [
      "Shop: +971 4 352 4118",
      "Catalog: +971 56 531 0733",
      "Mobile: +971 58 505 4666",
      "Juvarajan: +971 55 731 8850",
      "Insaaf: +971 55 841 9745"
    ]
  },
  {
    icon: Mail,
    title: "Email",
    details: ["Starminttradingcompany@gmail.com"]
  },
  {
    icon: Clock,
    title: "Business Hours",
    details: ["Saturday - Thursday: 10:00 AM - 10:00 PM", "Friday: 4:00 PM - 10:00 PM"]
  }
];

export default function Contact() {
  return (
    <section id="contact" className="py-20 px-6 bg-background" data-testid="section-contact">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4" data-testid="text-contact-title">
            Visit Us
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-primary to-transparent mx-auto mb-4"></div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-contact-description">
            Experience our collection in person at Dubai's iconic Gold Souq
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {contactInfo.map((info, index) => (
            <Card 
              key={index}
              className="p-8 bg-card border-card-border hover-elevate"
              data-testid={`card-contact-${index}`}
            >
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-full bg-primary/10 border border-primary/30">
                  <info.icon className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg text-foreground mb-3" data-testid={`text-contact-info-title-${index}`}>
                    {info.title}
                  </h3>
                  {info.details.map((detail, idx) => (
                    <p 
                      key={idx} 
                      className="text-muted-foreground text-sm mb-1"
                      data-testid={`text-contact-detail-${index}-${idx}`}
                    >
                      {detail}
                    </p>
                  ))}
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-sm text-muted-foreground mb-4" data-testid="text-website">
            Visit our website: <a href="https://www.starminttradingcompany.ae" className="text-primary hover:underline" data-testid="link-website">www.starminttradingcompany.ae</a>
          </p>
        </div>
      </div>
    </section>
  );
}
