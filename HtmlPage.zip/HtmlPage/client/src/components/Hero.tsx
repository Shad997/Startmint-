import { Button } from "@/components/ui/button";
import starmintLogo from "@assets/1744184644734-removebg-preview_1762756809920.png";
import backgroundImg from "@assets/black-abstract-textured-grunge-background-wall-with-slanted-stripes-vector_1762756961796.jpg";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section 
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        backgroundImage: `url(${backgroundImg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
      data-testid="section-hero"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/80" />
      
      <div className="relative z-10 text-center px-6 py-20">
        <div className="mb-8 animate-fade-in">
          <div className="inline-block p-8 rounded-full border-2 border-primary/30 bg-black/40 backdrop-blur-sm">
            <img 
              src={starmintLogo} 
              alt="Starmint Trading Company Logo" 
              className="w-64 h-64 md:w-80 md:h-80 object-contain drop-shadow-2xl"
              data-testid="img-logo"
            />
          </div>
        </div>
        
        <h1 className="font-serif text-5xl md:text-7xl font-bold text-primary mb-4 tracking-wide drop-shadow-lg" data-testid="text-hero-title">
          STARMINT TRADING COMPANY
        </h1>
        
        <p className="text-xl md:text-2xl text-foreground/90 font-light mb-8 tracking-widest" data-testid="text-hero-subtitle">
          Exquisite Gold Jewelry & Trading
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            size="lg"
            className="bg-primary/90 backdrop-blur-md hover:bg-primary text-primary-foreground font-semibold px-8 border border-primary"
            onClick={() => scrollToSection('gallery')}
            data-testid="button-view-collection"
          >
            View Collection
          </Button>
          <Button 
            size="lg"
            variant="outline"
            className="bg-black/40 backdrop-blur-md border-primary/60 text-foreground hover:bg-primary/20 font-semibold px-8"
            onClick={() => scrollToSection('contact')}
            data-testid="button-contact-us"
          >
            Contact Us
          </Button>
        </div>
      </div>
    </section>
  );
}
