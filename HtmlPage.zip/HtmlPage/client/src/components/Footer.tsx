import starmintLogo from "@assets/1744184644734-removebg-preview_1762756809920.png";

export default function Footer() {
  return (
    <footer className="bg-card/50 border-t border-primary/20 py-12 px-6" data-testid="section-footer">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-3 gap-12 mb-8">
          <div>
            <img 
              src={starmintLogo} 
              alt="Starmint Logo" 
              className="w-24 h-24 object-contain mb-4"
              data-testid="img-footer-logo"
            />
            <h3 className="font-serif text-xl font-bold text-primary mb-2" data-testid="text-footer-company">
              Starmint Trading Company
            </h3>
            <p className="text-sm text-muted-foreground" data-testid="text-footer-tagline">
              Luxury Gold Jewelry in the Heart of Dubai
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold text-foreground mb-4" data-testid="text-footer-quicklinks-title">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#gallery" className="text-muted-foreground hover:text-primary transition-colors text-sm" data-testid="link-footer-collection">Our Collection</a></li>
              <li><a href="#about" className="text-muted-foreground hover:text-primary transition-colors text-sm" data-testid="link-footer-about">About Us</a></li>
              <li><a href="#contact" className="text-muted-foreground hover:text-primary transition-colors text-sm" data-testid="link-footer-contact">Contact</a></li>
              <li><a href="https://www.starminttradingcompany.ae" className="text-muted-foreground hover:text-primary transition-colors text-sm" data-testid="link-footer-website">Website</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-foreground mb-4" data-testid="text-footer-connect-title">Connect With Us</h4>
            <div className="flex gap-3">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-footer-facebook">
                <i className="fa-brands fa-facebook-f text-xl"></i>
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-footer-instagram">
                <i className="fa-brands fa-instagram text-xl"></i>
              </a>
              <a href="https://wa.me/971585054666" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-footer-whatsapp">
                <i className="fa-brands fa-whatsapp text-xl"></i>
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-footer-tiktok">
                <i className="fa-brands fa-tiktok text-xl"></i>
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-footer-youtube">
                <i className="fa-brands fa-youtube text-xl"></i>
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-primary/10 pt-8 text-center">
          <p className="text-sm text-muted-foreground" data-testid="text-footer-copyright">
            &copy; {new Date().getFullYear()} Starmint Trading Company L.L.C. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground mt-2" data-testid="text-footer-location">
            Shop No-04 Al Buteen Building 2, Gate No.1, Gold Souq, Deira, Dubai, UAE
          </p>
        </div>
      </div>
    </footer>
  );
}
