import { SpotRate } from '@/hooks/useLivePrices';
import { DollarSign } from 'lucide-react';

interface SpotRateCardProps {
  rate: SpotRate;
}

export default function SpotRateCard({ rate }: SpotRateCardProps) {
  return (
    <div className="bg-card/50 rounded-lg border-2 border-primary/30 p-6" data-testid={`card-spot-${rate.name.toLowerCase()}`}>
      <div className="mb-6">
        <div className="text-foreground/80 text-sm mb-2 uppercase tracking-wider" data-testid={`text-spot-label-${rate.name.toLowerCase()}`}>
          SPOT RATE
        </div>
        <div className="flex items-center justify-between mb-4">
          <div className="text-xl font-bold text-primary flex items-center gap-2" data-testid={`text-spot-name-${rate.name.toLowerCase()}`}>
            <DollarSign className="w-5 h-5 text-primary" />
            BID <span className="text-foreground">$</span>
          </div>
          <div className="text-xl font-bold text-primary flex items-center gap-2" data-testid={`text-spot-ask-label-${rate.name.toLowerCase()}`}>
            ASK <span className="text-foreground">$</span>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <div className="text-center font-bold text-lg mb-2 text-foreground" data-testid={`text-metal-${rate.name.toLowerCase()}`}>
            {rate.name}
          </div>
          <div className="bg-red-600 text-white text-4xl font-bold py-4 px-6 rounded-md text-center" data-testid={`text-bid-${rate.name.toLowerCase()}`}>
            {rate.bid.toFixed(rate.name.includes('SILVER') ? 3 : 2)}
          </div>
          <div className="bg-red-700 text-white text-sm font-semibold py-2 px-4 rounded-b-md text-center" data-testid={`text-low-${rate.name.toLowerCase()}`}>
            LOW {rate.low.toFixed(rate.name.includes('SILVER') ? 3 : 2)}
          </div>
        </div>
        
        <div>
          <div className="h-8"></div>
          <div className="bg-white dark:bg-white text-black text-4xl font-bold py-4 px-6 rounded-md text-center border-2 border-foreground/20" data-testid={`text-ask-${rate.name.toLowerCase()}`}>
            {rate.ask.toFixed(rate.name.includes('SILVER') ? 3 : 2)}
          </div>
          <div className="bg-green-600 text-white text-sm font-semibold py-2 px-4 rounded-b-md text-center" data-testid={`text-high-${rate.name.toLowerCase()}`}>
            HIGH {rate.high.toFixed(rate.name.includes('SILVER') ? 3 : 2)}
          </div>
        </div>
      </div>
    </div>
  );
}
