import { Card } from "@/components/ui/card";
import necklaceImg from "@assets/generated_images/Gold_filigree_necklace_0289fee9.png";
import braceletImg from "@assets/generated_images/Ornate_gold_bracelet_5cab761e.png";
import ringImg from "@assets/generated_images/Detailed_gold_ring_e1e481c6.png";
import earringsImg from "@assets/generated_images/Traditional_gold_earrings_f301be5a.png";
import chainImg from "@assets/generated_images/Heavy_gold_chain_d4e3685c.png";
import banglesImg from "@assets/generated_images/Carved_gold_bangles_2b6b5889.png";

const products = [
  { id: 1, name: "Gold Filigree Necklace", image: necklaceImg, category: "Necklaces" },
  { id: 2, name: "Ornate Gold Bracelet", image: braceletImg, category: "Bracelets" },
  { id: 3, name: "Detailed Gold Ring", image: ringImg, category: "Rings" },
  { id: 4, name: "Traditional Gold Earrings", image: earringsImg, category: "Earrings" },
  { id: 5, name: "Heavy Gold Chain", image: chainImg, category: "Necklaces" },
  { id: 6, name: "Carved Gold Bangles", image: banglesImg, category: "Bracelets" },
];

export default function ProductGallery() {
  return (
    <section id="gallery" className="py-20 px-6 bg-background" data-testid="section-gallery">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4" data-testid="text-gallery-title">
            Our Collection
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-primary to-transparent mx-auto mb-4"></div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-gallery-description">
            Discover our exquisite selection of handcrafted gold jewelry, each piece a masterpiece of artistry and elegance
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card 
              key={product.id}
              className="group relative overflow-hidden bg-card border-card-border hover-elevate cursor-pointer transition-all duration-300"
              data-testid={`card-product-${product.id}`}
            >
              <div className="aspect-square overflow-hidden bg-black/40">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  data-testid={`img-product-${product.id}`}
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                <div>
                  <p className="text-xs text-primary font-semibold tracking-widest mb-1" data-testid={`text-category-${product.id}`}>
                    {product.category}
                  </p>
                  <h3 className="text-xl font-serif text-foreground font-bold" data-testid={`text-name-${product.id}`}>
                    {product.name}
                  </h3>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
