import { Gem, Award, Users, Shield } from "lucide-react";

const features = [
  {
    icon: Gem,
    title: "Premium Quality",
    description: "Only the finest gold and precious stones"
  },
  {
    icon: Award,
    title: "Expert Craftsmanship",
    description: "Decades of jewelry-making expertise"
  },
  {
    icon: Users,
    title: "Personalized Service",
    description: "Dedicated to your satisfaction"
  },
  {
    icon: Shield,
    title: "Authentic & Certified",
    description: "Every piece comes with certification"
  }
];

export default function About() {
  return (
    <section id="about" className="py-20 px-6 bg-card/30" data-testid="section-about">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4" data-testid="text-about-title">
            About Starmint
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-transparent via-primary to-transparent mx-auto mb-8"></div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 mb-16">
          <div>
            <h3 className="font-serif text-2xl font-bold text-foreground mb-4" data-testid="text-story-title">
              Our Story
            </h3>
            <p className="text-muted-foreground leading-relaxed mb-4" data-testid="text-story-description">
              Located in the heart of Dubai's legendary Gold Souq, Starmint Trading Company L.L.C has been a beacon of luxury and craftsmanship for discerning jewelry enthusiasts. Our passion for excellence drives us to curate and create only the most exquisite gold pieces.
            </p>
            <p className="text-muted-foreground leading-relaxed" data-testid="text-story-mission">
              Every piece in our collection tells a story of artistry, tradition, and timeless elegance. We take pride in offering jewelry that becomes treasured heirlooms for generations to come.
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className="text-center p-6 rounded-md border border-primary/20 bg-card/50 hover-elevate"
                data-testid={`card-feature-${index}`}
              >
                <feature.icon className="w-10 h-10 text-primary mx-auto mb-3" />
                <h4 className="font-semibold text-foreground mb-2 text-sm" data-testid={`text-feature-title-${index}`}>
                  {feature.title}
                </h4>
                <p className="text-xs text-muted-foreground" data-testid={`text-feature-description-${index}`}>
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
