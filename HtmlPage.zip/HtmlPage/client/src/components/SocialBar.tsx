import { Button } from "@/components/ui/button";

const socialLinks = [
  { name: "Facebook", icon: "fa-brands fa-facebook-f", url: "#", color: "#1877F2" },
  { name: "Instagram", icon: "fa-brands fa-instagram", url: "#", color: "#E4405F" },
  { name: "WhatsApp", icon: "fa-brands fa-whatsapp", url: "https://wa.me/971585054666", color: "#25D366" },
  { name: "TikTok", icon: "fa-brands fa-tiktok", url: "#", color: "#000000" },
  { name: "YouTube", icon: "fa-brands fa-youtube", url: "#", color: "#FF0000" },
];

export default function SocialBar() {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3" data-testid="section-social-bar">
      {socialLinks.map((social, index) => (
        <Button
          key={index}
          size="icon"
          className="rounded-full bg-card/90 backdrop-blur-md border-2 border-primary/30 hover:bg-primary hover:border-primary transition-all duration-300 shadow-lg"
          onClick={() => window.open(social.url, '_blank')}
          data-testid={`button-social-${social.name.toLowerCase()}`}
        >
          <i className={`${social.icon} text-primary hover:text-primary-foreground text-lg`}></i>
        </Button>
      ))}
    </div>
  );
}
