import { useLivePrices } from '@/hooks/useLivePrices';
import CommodityTable from '@/components/CommodityTable';
import SpotRateCard from '@/components/SpotRateCard';
import starmintLogo from "@assets/1744184644734-removebg-preview_1762756809920.png";
import backgroundImg from "@assets/black-abstract-textured-grunge-background-wall-with-slanted-stripes-vector_1762756961796.jpg";

export default function Dashboard() {
  const { goldPrices, spotRates } = useLivePrices();
  
  return (
    <div 
      className="min-h-screen dark p-6"
      style={{
        backgroundImage: `url(${backgroundImg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
      data-testid="page-dashboard"
    >
      <div className="absolute inset-0 bg-black/70"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="bg-black/60 backdrop-blur-sm border-2 border-primary/40 rounded-lg p-6 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img 
              src={starmintLogo} 
              alt="Starmint Logo" 
              className="w-16 h-16 object-contain"
              data-testid="img-dashboard-logo"
            />
            <div>
              <h1 className="font-serif text-2xl font-bold text-primary tracking-wider" data-testid="text-dashboard-title">
                STARMINT TRADING COMPANY
              </h1>
              <p className="text-foreground/70 text-sm" data-testid="text-dashboard-subtitle">
                LIVE BULLION RATES
              </p>
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-xs text-muted-foreground mb-1">Last Updated</div>
            <div className="text-sm text-primary font-mono" data-testid="text-last-updated">
              {new Date().toLocaleTimeString('en-US', { hour12: false })}
            </div>
          </div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-6">
          <CommodityTable prices={goldPrices} />
          
          <div className="space-y-6">
            {spotRates.map((rate) => (
              <SpotRateCard key={rate.name} rate={rate} />
            ))}
          </div>
        </div>
        
        <div className="mt-6 bg-black/40 backdrop-blur-sm border border-primary/20 rounded-lg p-4 text-center">
          <p className="text-foreground/70 text-sm mb-2" data-testid="text-footer-info">
            Starmint Trading Company L.L.C | Shop No-04 Al Buteen Building 2, Gold Souq, Deira, Dubai
          </p>
          <p className="text-muted-foreground text-xs" data-testid="text-footer-contact">
            📞 +971 58 505 4666 | 📧 Starminttradingcompany@gmail.com
          </p>
        </div>
      </div>
    </div>
  );
}
