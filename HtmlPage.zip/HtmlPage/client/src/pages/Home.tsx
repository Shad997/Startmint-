import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import ProductGallery from "@/components/ProductGallery";
import About from "@/components/About";
import Contact from "@/components/Contact";
import SocialBar from "@/components/SocialBar";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background dark">
      <Navigation />
      <Hero />
      <Marquee />
      <ProductGallery />
      <About />
      <Contact />
      <SocialBar />
      <Footer />
    </div>
  );
}
