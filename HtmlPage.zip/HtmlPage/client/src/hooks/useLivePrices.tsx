import { useState, useEffect } from 'react';

export interface CommodityPrice {
  commodity: string;
  purity: string;
  unit: string;
  bid: number;
  ask: number;
  low?: number;
  high?: number;
}

export interface SpotRate {
  name: string;
  bid: number;
  ask: number;
  low: number;
  high: number;
}

// Simulated real-time price updates
export function useLivePrices() {
  const [goldPrices, setGoldPrices] = useState<CommodityPrice[]>([
    { commodity: 'GOLD', purity: '999', unit: '1 GM', bid: 480.63, ask: 482.27 },
    { commodity: 'GOLD', purity: '9999', unit: '1 KG', bid: 481064, ask: 482705 },
    { commodity: 'GOLD', purity: '995', unit: '1 KG', bid: 478706, ask: 480340 },
    { commodity: 'GOLD', purity: 'TEN TOLA', unit: '1 TTB', bid: 56061, ask: 56252 },
  ]);

  const [spotRates, setSpotRates] = useState<SpotRate[]>([
    { name: 'GOLDoz', bid: 4072.95, ask: 4074.85, low: 3997.81, high: 4078.36 },
    { name: 'SILVERoz', bid: 49.452, ask: 49.502, low: 48.342, high: 49.573 },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate price fluctuations while maintaining BID < ASK spread
      setGoldPrices(prev => prev.map(price => {
        const currentSpread = price.ask - price.bid;
        const volatility = price.unit === '1 GM' ? 0.3 : 30;
        const midChange = (Math.random() - 0.5) * volatility;
        const newMid = (price.bid + price.ask) / 2 + midChange;
        
        return {
          ...price,
          bid: parseFloat((newMid - currentSpread / 2).toFixed(price.unit === '1 GM' ? 2 : 0)),
          ask: parseFloat((newMid + currentSpread / 2).toFixed(price.unit === '1 GM' ? 2 : 0)),
        };
      }));

      setSpotRates(prev => prev.map(rate => {
        const currentSpread = rate.ask - rate.bid;
        const volatility = rate.name.includes('SILVER') ? 0.5 : 3;
        const midChange = (Math.random() - 0.5) * volatility;
        const newMid = (rate.bid + rate.ask) / 2 + midChange;
        const newBid = newMid - currentSpread / 2;
        const newAsk = newMid + currentSpread / 2;
        
        return {
          ...rate,
          bid: parseFloat(newBid.toFixed(rate.name.includes('SILVER') ? 3 : 2)),
          ask: parseFloat(newAsk.toFixed(rate.name.includes('SILVER') ? 3 : 2)),
          low: Math.min(rate.low, newBid),
          high: Math.max(rate.high, newAsk),
        };
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return { goldPrices, spotRates };
}
