# Starmint Trading Company - Luxury Gold Jewelry E-commerce

## Overview

This is a luxury e-commerce website for Starmint Trading Company L.L.C, a Dubai-based gold jewelry and trading business located in the Gold Souq. The application features a sophisticated, high-end design inspired by luxury jewelry brands like Cartier and Tiffany & Co., with a focus on dramatic visuals and exceptional product presentation.

The application is built as a full-stack TypeScript project with a React frontend and Express backend, featuring both a public-facing luxury e-commerce experience and a live bullion rates dashboard.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast HMR (Hot Module Replacement)
- Wouter for lightweight client-side routing
- Single-page application (SPA) architecture with route-based code splitting

**UI Component System**
- shadcn/ui component library with Radix UI primitives for accessible, unstyled components
- Tailwind CSS for utility-first styling with custom design tokens
- Custom design system based on luxury e-commerce aesthetics (defined in `design_guidelines.md`)
- Typography: Playfair Display (serif), Montserrat (sans-serif), Cinzel (accent font) from Google Fonts
- Color scheme: Gold accents (#D4AF37 range) with neutral backgrounds
- Dark mode support with CSS variables for theming

**State Management**
- TanStack Query (React Query) for server state management and data fetching
- Local component state with React hooks
- Custom hooks pattern for reusable logic (e.g., `useLivePrices`, `useIsMobile`)

**Key Pages & Components**
- **Home Page**: Full luxury e-commerce experience with hero section, product gallery, about section, and contact information
- **Dashboard Page**: Live bullion rates display with real-time price updates
- Reusable components: Navigation, Hero, ProductGallery, CommodityTable, SpotRateCard, SocialBar, Footer

**Real-time Features**
- Simulated live price updates for gold and silver commodities using `setInterval`
- Auto-updating timestamp display
- Smooth animations and transitions for price changes

### Backend Architecture

**Server Framework**
- Express.js with TypeScript for the HTTP server
- HTTP server created using Node's built-in `http` module
- Middleware stack: JSON body parsing, URL-encoded parsing, request logging

**Development Setup**
- tsx for TypeScript execution in development
- Vite middleware integration for development with HMR
- Custom logging system with formatted timestamps
- Development-only Replit plugins for error overlay and cartographer

**API Structure**
- RESTful API design pattern (routes prefixed with `/api`)
- Centralized route registration in `server/routes.ts`
- Request/response logging with truncation for readability
- Raw body preservation for webhook handling

**Storage Layer**
- Abstract storage interface (`IStorage`) for database operations
- In-memory storage implementation (`MemStorage`) for development
- Designed to be swapped with production database (Drizzle ORM configured)
- CRUD operations for users (extensible to products, orders, etc.)

### Data Storage Solutions

**Database Configuration**
- Drizzle ORM configured for PostgreSQL via Neon serverless driver
- Schema-first approach with TypeScript types generated from Drizzle schemas
- Zod integration for runtime validation of insert operations
- Migration system configured (output to `./migrations`)

**Current Schema**
- Users table with UUID primary keys, username, and password fields
- Designed to be extended for e-commerce entities (products, categories, orders, customers)

**Data Models**
- Type-safe models using Drizzle's type inference
- Validation schemas using drizzle-zod for insert operations
- Separation of Insert types and Select types

### Authentication & Authorization

**Current Implementation**
- Basic user model with username/password fields
- Session management setup with connect-pg-simple for PostgreSQL-backed sessions
- Express session middleware configured (implied by dependency presence)

**Planned Security**
- Password hashing (bcrypt dependency available)
- Session-based authentication
- CSRF protection for forms
- Secure cookie configuration

### External Dependencies

**Third-party Services**
- **Font Awesome Kit**: Icon library (kit ID: 111183188) for social media icons and UI elements
- **Google Fonts**: Playfair Display, Montserrat, and Cinzel for typography
- **Neon Database**: Serverless PostgreSQL database for production data storage

**Key NPM Packages**
- **UI Components**: Radix UI primitives (@radix-ui/*) for accessible component foundation
- **Forms**: React Hook Form with Hookform Resolvers for form validation
- **Styling**: Tailwind CSS, class-variance-authority, clsx for utility composition
- **Date Handling**: date-fns for date formatting and manipulation
- **Carousels**: embla-carousel-react for product image galleries
- **Database**: Drizzle ORM with Neon serverless driver, connect-pg-simple for sessions
- **Development**: Replit-specific plugins for enhanced developer experience

**Asset Management**
- Static assets served from `attached_assets` directory
- Product images stored in `attached_assets/generated_images`
- Background textures and branding assets
- Vite alias configuration for easy asset imports (`@assets`)

**Build & Deployment**
- Production build: Vite for frontend, esbuild for backend bundling
- ESM module format throughout the project
- Separate output directories: `dist/public` for frontend, `dist` for backend
- Environment variable configuration via `.env` (DATABASE_URL required)