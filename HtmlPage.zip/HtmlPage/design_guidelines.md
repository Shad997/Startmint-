# STARMINT TRADING COMPANY - Design Guidelines

## Design Approach
**Reference-Based: Luxury E-commerce**
Drawing inspiration from high-end jewelry brands (Cartier, Tiffany & Co., Bulgari) and premium Shopify stores. Focus on sophisticated elegance, dramatic visuals, and exceptional product presentation that conveys exclusivity and craftsmanship.

## Core Design Elements

### Typography
- **Primary Font**: "Playfair Display" (serif, luxury feel) via Google Fonts
  - Hero/Headers: 700 weight, 48-72px
  - Subheadings: 600 weight, 24-32px
- **Secondary Font**: "Montserrat" (sans-serif, clean readability)
  - Body text: 400 weight, 16-18px
  - Buttons/CTAs: 500 weight, 14-16px
  - Contact details: 300 weight, 14px
- **Accent Font**: "Cinzel" for company name in marquee (elegant, refined)

### Layout System
**Tailwind spacing primitives**: Use units of 4, 6, 8, 12, 16, 20, 24 for consistent rhythm
- Section padding: py-20 (desktop), py-12 (mobile)
- Component spacing: gap-8, space-y-6
- Container max-width: max-w-7xl with px-6

### Component Library

**Navigation**
- Fixed transparent header with backdrop blur on scroll
- Starmint logo (left), contact CTA button (right)
- Mobile: hamburger menu with full-screen overlay

**Hero Section**
- Full viewport height (min-h-screen) with provided black textured background
- Centered Starmint logo (large, prominent - approximately 300-400px width)
- Gold accent border/frame around logo
- Elegant tagline below: "Exquisite Gold Jewelry & Trading"
- Subtle parallax scroll effect on background
- Blurred-background CTA buttons: "View Collection" and "Contact Us"

**Scrolling Marquee**
- Horizontal infinite scroll below hero
- Text: "STARMINT TRADING COMPANY L.L.C • FINE GOLD JEWELRY • DUBAI • LUXURY CRAFTSMANSHIP •"
- Gold gradient text effect
- Speed: 40s duration

**Product Gallery Section**
- Masonry grid layout (Pinterest-style) for jewelry showcase
- 3 columns desktop, 2 tablet, 1 mobile
- Each card: hover zoom effect, gold border glow on hover
- Overlay: product name and "View Details" link
- Categories: Necklaces, Rings, Bracelets, Earrings, Custom Pieces

**About Section**
- 2-column layout: company description (left), why choose us (right)
- Gold decorative dividers
- Key highlights with gold bullet icons

**Contact Information Section**
- Dark card with gold accents
- Business details from card:
  - Company name: STARMINT TRADING COMPANY L.L.C
  - Address: Gold Souk, Deira, Dubai, UAE
  - Phones: +971 55 314 0048 / +971 50 444 8842
  - Email: starminttrading@gmail.com
- Embedded Google Maps (optional integration point)
- Operating hours display

**Social Media Bar**
- Fixed bottom or side sticky bar
- Icons: Facebook, Instagram, WhatsApp, TikTok, YouTube
- Gold hover effects with subtle animations
- WhatsApp: direct click-to-chat functionality

**Footer**
- Three columns: Company Info | Quick Links | Connect
- Gold line separator at top
- Copyright and business license info
- Social links repeated

### Visual Effects
- **Scroll Animations**: Fade-in-up for sections (using Intersection Observer)
- **Product Cards**: Transform scale(1.05) on hover
- **Gold Shimmer**: Subtle animated gradient on headings
- **Backdrop Blur**: 12px blur on navigation and overlay elements
- **Parallax**: Background image subtle movement (0.5 speed)

### Responsive Breakpoints
- Mobile: < 768px (single column, stacked layout)
- Tablet: 768px - 1024px (2-column grids)
- Desktop: > 1024px (full multi-column experience)

## Images

**Hero Background**: Use provided black textured grunge background (full coverage, fixed attachment)

**Logo Placement**: Starmint logo centered in hero section with gold accent frame/border

**Product Images**: Placeholder jewelry images in gallery grid (high-quality gold jewelry photos - necklaces, rings, bracelets, earrings)

**Decorative Elements**: 
- Gold ornamental dividers between sections
- Subtle jewelry-themed vector patterns as section accents
- Business card details integrated into contact section design

## Accessibility & Performance
- Semantic HTML5 structure
- ARIA labels for navigation and interactive elements
- Alt text for all images
- Lazy loading for product gallery images
- Optimized image formats (WebP with fallbacks)
- Keyboard navigation support
- Minimum touch target sizes: 48x48px

**Critical**: This is a luxury showcase website - prioritize visual impact, smooth animations, and premium feel throughout. Every element should communicate exclusivity and craftsmanship.